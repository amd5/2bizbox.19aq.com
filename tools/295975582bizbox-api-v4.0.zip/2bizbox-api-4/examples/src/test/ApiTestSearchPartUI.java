package test;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import bb.common.*;
import bb.common.box.*;
import bb.gui.server.*;
import bb.gui.swing.*;

public class ApiTestSearchPartUI extends JFrame {

	private JTextField txtServer = new JTextField("localhost", 8);
	private JTextField txtPort = new JTextField("80", 4);
	private JTextField txtCompany = new JTextField("TEST", 4);
	private JTextField txtUser = new JTextField("admin", 8);
	private JPasswordField txtPassword = new JPasswordField("", 8);
	private JTextField txtSearch = new JTextField(8);
	private JTextArea txtResult = new JTextArea();
	private JButton btnConnect = new JButton("Connect");

	public ApiTestSearchPartUI() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("2BizBox API Test");
		this.setSize(900, 600);
		this.setLocation(300, 300);

		JPanel settingPane = new JPanel(new FlowLayout(FlowLayout.LEADING, 0, 0));
		settingPane.add(new JLabel("Server:"));
		settingPane.add(this.txtServer);
		settingPane.add(new JLabel("  "));
		settingPane.add(new JLabel("Port:"));
		settingPane.add(this.txtPort);
		settingPane.add(new JLabel("  "));
		settingPane.add(new JLabel("Company:"));
		settingPane.add(this.txtCompany);
		settingPane.add(new JLabel("  "));
		settingPane.add(new JLabel("User:"));
		settingPane.add(this.txtUser);
		settingPane.add(new JLabel("  "));
		settingPane.add(new JLabel("Password:"));
		settingPane.add(this.txtPassword);
		settingPane.add(new JLabel("  "));
		settingPane.add(new JLabel("Search:"));
		settingPane.add(this.txtSearch);

		JPanel topPane = new JPanel(new BorderLayout());
		topPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		topPane.add(settingPane, BorderLayout.CENTER);
		topPane.add(btnConnect, BorderLayout.EAST);
		this.add(topPane, BorderLayout.NORTH);
		JPanel resultPane = new JPanel(new BorderLayout());
		resultPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		resultPane.add(new JScrollPane(txtResult), BorderLayout.CENTER);
		this.add(resultPane, BorderLayout.CENTER);

		this.btnConnect.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					initServer();
					findPartsByDescriptionInside();
				} catch (Exception ex) {
					ExceptionWorker worker = new ExceptionWorker(ex);
					String message = worker.getMessage();
					JOptionPane.showMessageDialog(ApiTestSearchPartUI.this, message);
				}
			}
		});
	}

	private void initServer() {
		String server = this.txtServer.getText().trim();
		String port = this.txtPort.getText().trim();
		String company = this.txtCompany.getText().trim();
		String user = this.txtUser.getText().trim();
		String password = new String(this.txtPassword.getPassword());
		String language = "en_US";
		BizBoxServer targetServer = new BizBoxServer(server, port, company, user, password, language);
		ServerActionUtil.setTargetServer(targetServer);
	}

	private void findPartsByDescriptionInside() throws Exception {
		EngineeringBox eng = EngServerActionManager.getInstance();
		String search = this.txtSearch.getText().trim();
		Collection<PartBasicInfo> parts = eng.findPartsByDescriptionInside("", "", search,"en_US", 0, 100);
		String result = "";
		if (parts != null) {
			Iterator<PartBasicInfo> it = parts.iterator();
			while (it.hasNext()) {
				PartBasicInfo part = it.next();
				result += part.getPartPk().getPartNumber();
				result += "\t";
				result += part.getDescription();
				result += "\n";
			}
		}
		this.txtResult.setText(result);
	}

	public static void main(String[] args) throws Exception {
		ApiTestSearchPartUI ui = new ApiTestSearchPartUI();
		ui.setVisible(true);
	}
}
