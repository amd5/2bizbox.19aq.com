package test;


import bb.common.*;
import bb.gui.server.*;

public class ApiTest {

    public static void main(String[] args) throws Exception {
        BizBoxServer server = new BizBoxServer("localhost", "80", "test", "admin", "", "en_US");
        ServerActionUtil.setTargetServer(server);

        EngServerActionManager eng = EngServerActionManager.getInstance();
        int count = eng.getAllPartsCount();
        System.out.println("Total BOM count:" + count);
    }
}
